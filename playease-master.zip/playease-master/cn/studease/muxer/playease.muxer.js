﻿(function(playease) {
	playease.muxer = {};
})(playease);
