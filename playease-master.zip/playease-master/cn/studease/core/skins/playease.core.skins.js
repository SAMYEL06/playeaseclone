﻿(function(playease) {
	var skins = playease.core.skins = {};
	
	skins.types = {
		DEFAULT: 'def'
	};
})(playease);
