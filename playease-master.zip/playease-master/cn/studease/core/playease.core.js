﻿(function(playease) {
	playease.core = {};
})(playease);
