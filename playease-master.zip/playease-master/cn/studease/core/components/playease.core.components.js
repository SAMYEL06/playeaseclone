﻿(function(playease) {
	playease.core.components = {};
})(playease);
