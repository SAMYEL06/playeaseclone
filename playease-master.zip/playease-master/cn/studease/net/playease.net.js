﻿(function(playease) {
	playease.net = {};
})(playease);
