﻿(function(playease) {
	playease.utils.matchers = {};
})(playease);
